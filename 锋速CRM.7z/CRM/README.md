crm
===

用golang构建CRM系统,基于Mongo数据库

安装:
需要有mongo做数据库存储.
在/conf/app.conf中修改mongo数据库连接.
源码运行go run main.go

或者直接运行编译好的crm.exe,
然后访问http://127.0.0.1:8080/

锋子
2015年1月25日 07:49:26

